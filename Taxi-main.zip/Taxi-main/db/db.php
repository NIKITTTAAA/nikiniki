<?php

$link = mysqli_connect("localhost", "taxi", "123456", "taxi");
if(!$link) {
    echo "err";
}

?>